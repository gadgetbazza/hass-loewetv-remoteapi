DOMAIN = "loewe_tv"

CONF_HOST = "host"
CONF_NAME = "name"
DEFAULT_NAME = "Loewe TV"
